# Declaració de constants i variables
DISTANCIA: int = 0
LLINDAR_STOP: int = 20
LLINDAR_LENT: int = 50
accio: str = ""

# TODO: En un bucle, demana una distància o 'q' per sortir.
#       Si no és enter vàlid, mostra avís i torna a demanar.
#       Si DISTANCIA < 20 -> STOP
#          20 <= DISTANCIA <= 50 -> LENT
#          DISTANCIA > 50 -> RÀPID
#       Mostra l'acció triada.
