from datetime import date

# Declaració de variables (disciplina d'inicialització buida)
nom: str = ""
edat: int = 0

# TODO 1: Demana el nom (amb .strip()) i desarà'l a 'nom'
# TODO 2: Demana l'edat com a text, valida que sigui un enter > 0 i guarda'l a 'edat'
#         Pista: usa un bucle while i .isdigit()
# TODO 3: Calcula l'any de naixement a partir de l'any actual (date.today().year)
# TODO 4: Imprimeix els missatges amb f-strings i indica si és major d'edat (>=18)
