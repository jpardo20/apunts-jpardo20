# Declaració de variables
nota: float = 0.0

# TODO 1: Demana una nota (0-10). Accepta coma o punt (ex: "7,5" o "7.5").
# TODO 2: Valida que 0.0 <= nota <= 10.0 (bucle while + try/except)
# TODO 3: Calcula la menció segons la nota:
#         >= 9 -> "Excel·lent"
#         >= 7 -> "Notable"
#         >= 5 -> "Aprovat"
#         < 5  -> "Suspès"
# TODO 4: Mostra "Nota: X -> Menció"
