---
layout: page
title: "Components d’un equip microinformàtic"
---

> Versió generada automàticament des d'una presentació .pptx el 2025-10-12 21:29.


# Components d’un equip microinformàtic


## Components d’un equip microinformàtic

- Memòria RAM
- ‹#›
- ¡Todo, TODO sobre la RAM! - Parte 1&2 | Nate Labs
- https://www.youtube.com/watch?v=yRNwl24l39E
- https://www.youtube.com/watch?v=OZCEHXlHY4E


## La memòria RAM

- És un dispositiu on s’emmagatzemen les dades i les instruccions necessàries per executar el software de l’equip.
- Són volàtils, és a dir, necessiten estar constantment alimentades. Si perden l’alimentació, perden la informació.
- ‹#›


## Característiques

- Volatilitat
  - És una característica de les memòries RAM que determina el temps que romanen les dades abans de desaparèixer.
  - RAM dinàmiques (DRAM) Condensadors. Emmagatzemen la informació per un temps i necessita ser realimentada (refrescada) per conservar les dades.
  - RAM estàtica (SRAM) Biestables. Constantment estan alimentades i no necessiten cicles de refresc.
- ‹#›


## Característiques

- Capacitat
  - Quantitat de dades que es poden emmagatzemar en memòria. Es mesura en múltiples de byte (MB, GB, etc.).
  - Velocitat d’accés
  - És el temps que triga la CPU en accedir a la memòria (per llegir o escriure). Es mesura en nanosegons.
- Velocitat o freqüència de rellotge
  - És el nombre d'accessos a memòria que es poden realitzar en 1 segon. Es mesura en Hertz (Hz).
- Latència
  - És el retard produït en cada accés a memòria.
- ‹#›


## Característiques

- Taxa de transferència o ample de banda
  - Representa el nombre de dades que es poden llegir o escriure per unitat de temps. Es mesura en MB/s o GB/s.
- Voltatge
  - És la tensió que necessita la RAM per funcionar. Com menys voltatge, menys consum.
- ECC (Error Checking and Correction)
  - Totes les RAMs experimenten errors. Les memòria ECC són capaces de detectar i corregir alguns dels errors.
- ‹#›


## Càlcul de latències

- Fórmules:
  - Taxa de transferència = Freqüència  efectiva(MHz) x Ample bus de dades(bytes)
  - Freqüència efectiva = Velocitat de rellotge (MHz) x Nº d’accessos per cicle
  - Taxa de transferència = Velocitat de rellotge (MHz) x
  - Nº d’accessos per cicle x
  - Ample de bus (bytes)
- ‹#›


## Càlcul de latències

- Taxa de transferència = Velocitat de rellotge (MHz) x
- Nº d’accessos per cicle x
- Ample de bus (bytes)
- Nombre d'accessos per cicle:
  - SDR: 1n accés/cicle
  - DDR: 2n accessos/cicle
  - DDR2: 4n accessos/cicle
  - DDR3: 8n accessos/cicle
  - DDR4: 8n accessos x nº grups-banks/cicle (es pot considerar 16n )
- Ample de bus:
  - 64bits 🡪 64/8 = 8 Bytes
- DDR: Double Data Rate (Doble taxa de dades)
- ‹#›


## Prefetch (accessos per cicle)

- ‹#›


## Exemple 1 de càlcul de latències

- Calcula l’equivalència d’una memòria DDR3-1600:
  - DDR3🡪PC3🡪8 accessos/cicle
  - 1600 🡪 1600 MHz de freqüència efectiva
  - Ample de bus = 8Bytes
  - Taxa transferència = Freq. Efectiva x Ample de bus
  - = 1600 x 8 = 12800 MB/s
  - Equivalència 🡪 PC3 – 12800
  - Velocitat de rellotge = Freq. efectiva/accessos = 1600/8= 200MHz
- ‹#›


## Exemple 2 de càlcul de latències

- Calcula l’equivalència d’una memòria PC2-3200
  - PC2🡪DDR2🡪 4 accessos/cicle
  - 3200🡪3200 MB/s de taxa de transferència
  - Ample de bus = 8Bytes
  - Taxa transferència = Freq. Efectiva x Ample de bus
  - 🡪 Freq. Efectiva = 3200 / 8 = 400 MHz
  - Equivalència: DDR2-400
  - Velocitat rellotge = Freq. Efectiva / accessos = 400/4 = 100 Mhz
- ‹#›


## Tipus de Mòduls

- Hi ha diferents tipus de mòduls, per a diferents sòcols.
- ‹#›


## Tipus de Mòduls

- Hi ha diferents tipus de mòduls, per a diferents sòcols.
- ‹#›


## Evolució

- ‹#›


## Tipus de Mòduls

- Hi ha diferents tipus de mòduls, per a diferents sòcols.
  - SIMM
    - Antic (PCs 32bits). 30 o 72 contactes.
  - DIMM
    - Actuals (PCs 64bits). 168, 184, 240, 288 contactes.
  - SO-DIMM
    - Actuals (Portàtils). 144, 200, 204 contactes.
  - Micro-DIMM
    - Actuals (Netbooks). 144, 172 i 214 contactes.
- ‹#›


## Tipus de Mòduls

- Hi ha diferents tipus de mòduls, per a diferents sòcols.
  - SIMM
    - Antic (PCs 32bits). 30 o 72 contactes.
  - DIMM
    - Actuals (PCs 64bits). 168, 184 i 240 contactes. (SDR, DDR/DDR2, DDR3,DDR4)
  - SO-DIMM
    - Actuals (Portàtils). 144, 200, 204 contactes. (SDR, DDR/DDR2, DDR3,DDR4)
  - Micro-DIMM
    - Actuals (Netbooks). 144, 172 i 214 contactes. (SDR, DDR/DDR2, DDR3)
- ‹#›


## Tipus de memòria RAM

- SRAM
  - Memòria RAM estàtica. Manté la informació mentre estigui alimentada. Ocupen més, tenen menys capacitat i són més cares i ràpides que les DRAM. Es fan servir com a cau
- DRAM
  - És la memòria principal dels ordinadors. Es diu dinàmica per que la seva informació es reescriu constantment.
    - SDRAM: se sincronitza amb el rellotge del sistema per llegir i escriure
    - RDRAM:  Antigues memòries de gama alta desenvolupades per Rambus Inc. En desús.
- ‹#›


## Tipus de memòria RAM

- SDRAM
  - SDR SDRAM
    - Antigues, PCs antics 32bits.
  - DDR SDRAM
    - Millora sobre les memòries SDRAM que incorpora doble taxa de transferència de dades.
  - DDR2 SDRAM
    - Millora sobre la DDR SDRAM que aumenta la velocitat, la capacitat i redueix el consum.
  - DDR3 SDRAM
    - Millora sobre la DDR2 SDRAM que aumenta la taxa de transferència, la capacitat i redueix el consum.
- DDR4 SDRAM
  - Millora sobre la DDR3 SDRAM que aumenta la velocitat, la capacitat i redueix el consum.
- ‹#›


## Tipus de memòria RAM

- ‹#›
