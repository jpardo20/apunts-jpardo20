# RA4 · Validació d'XML: DTD i XML Schema (XSD)

> **Versió base** · 2025-10-18 · Preparat per MkDocs · Estructura: RA/CA → Continguts → Exemples → Microexercicis → CA vinculats → Enllaços


## Objectius del RA
Describir i aplicar tècniques de **definició i validació** d'XML amb **DTD** i **XSD**, associant esquemes als documents i utilitzant eines de validació.

## Continguts clau
- Per què validar: qualitat, robustesa, intercanvi fiable.
- **DTD**: elements, atributs, quantificadors (`? * +`), tipus d'atribut (`ID`, `IDREF`…), entitats.
- **XSD** 1.0/1.1: tipus simples/complexos, restriccions (`pattern`, `minInclusive`…), cardinalitats, namespaces.
- Associació: `<!DOCTYPE …>` (DTD) i `xsi:noNamespaceSchemaLocation`/`xsi:schemaLocation` (XSD).
- Eines: `xmllint`, complements VS Code, validació online.

## Exemple breu (DTD vs XSD)
```dtd
<!ELEMENT cataleg (producte+)>
<!ELEMENT producte (nom, preu)>
<!ATTLIST producte id ID #REQUIRED>
```
```xml
<!-- XSD (fragment) -->
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <xsd:element name="cataleg">
    <xsd:complexType>
      <xsd:sequence>
        <xsd:element name="producte" maxOccurs="unbounded">
          <xsd:complexType>
            <xsd:sequence>
              <xsd:element name="nom" type="xsd:string"/>
              <xsd:element name="preu" type="xsd:decimal"/>
            </xsd:sequence>
            <xsd:attribute name="id" type="xsd:ID" use="required"/>
          </xsd:complexType>
        </xsd:element>
      </xsd:sequence>
    </xsd:complexType>
  </xsd:element>
</xsd:schema>
```

## Microexercicis
1. Dona dos exemples que el DTD acceptaria però l'XSD rebutjaria (p. ex. `preu` amb text “catorze”, `id` duplicat).
2. Associa un `xsi:noNamespaceSchemaLocation="cataleg.xsd"` a un document i valida'l.
3. Afegeix una restricció perquè `preu` tingui 2 decimals i sigui ≥ 0.

## CA vinculats (resum)
- Identifica tecnologies de definició i validació (DTD/XSD) i la seva sintaxi.
- Crea i associa esquemes a documents.
- Valida documents amb eines adequades.

## Enllaços útils
- Especificació XSD (W3C).
- Documentació `xmllint` i extensions VS Code per XML.
