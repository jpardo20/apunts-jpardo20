# RA2 · Web: HTML5, CSS i validació

> **Versió base** · 2025-10-18 · Preparat per MkDocs · Estructura: RA/CA → Continguts → Exemples → Microexercicis → CA vinculats → Enllaços


## Objectius del RA
Dominar l'estructura bàsica d'un document **HTML5** i aplicar **CSS** per a l'estil, tenint en compte semàntica, accessibilitat mínima i validació estàndard.

## Continguts clau
- Estructura HTML5: `<!doctype html>`, `<head>`, `<body>`; metaetiquetes bàsiques (`charset`, `viewport`).
- Semàntica: `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`.
- Accessibilitat essencial: textos alternatius (`alt`), associació `label`–`input`, ordre de capçaleres.
- CSS: selectores, cascada i herència, **box model**, unitats (`rem`, `%`, `fr`), media queries (nocions).
- Validació HTML/CSS: eines i errors típics (atributs obsolets, elements mal niats, `alt` absent).

## Exemple breu (HTML + CSS)
```html
<!doctype html>
<html lang="ca">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Catàleg</title>
    <link rel="stylesheet" href="estils.css">
  </head>
  <body>
    <main>
      <article class="producte">
        <h2>Ratolí</h2>
        <p class="preu">14,95 €</p>
        <button type="button">Afegir</button>
      </article>
    </main>
  </body>
</html>
```
```css
* { box-sizing: border-box; }
.producte { padding: 1rem; border: 1px solid #ccc; }
.producte .preu { font-weight: 700; }
@media (min-width: 640px) { main { max-width: 60ch; margin: auto; } }
```

## Microexercicis
1. Valida una pàgina HTML i anota 3 errors; proposa la correcció.
2. Afegeix una navegació `<nav>` amb enllaços interns i comprova l'ordre de capçaleres `h1…h3`.
3. Modifica l'estil perquè el preu es mostri alineat a la dreta al viewport ≥ 640px.

## CA vinculats (resum)
- Reconeix versions/estàndards HTML i bones pràctiques semàntiques.
- Aplica i valida **CSS**, considerant accessibilitat bàsica.
- Coneix la sindicació (RSS/Atom) i l'ús a la web (introducció).

## Enllaços útils
- MDN HTML (guia i referència d'elements).
- W3C Validator (HTML) i CSS Validator.
