# RA5 · Transformacions i conversió: XSLT → HTML/altres formats

> **Versió base** · 2025-10-18 · Preparat per MkDocs · Estructura: RA/CA → Continguts → Exemples → Microexercicis → CA vinculats → Enllaços


## Objectius del RA
Construir especificacions de **transformació XSLT** per convertir documents XML a **HTML** o altres formats d'intercanvi (CSV, text), i integrar-les en un flux bàsic de publicació.

## Continguts clau
- Pipeline de conversió: origen XML → XSLT → sortida (HTML/CSV/altres).
- XSLT 1.0: plantilles, `match`, `apply-templates`, `value-of`, `for-each`, condicions (`if`, `choose`), `sort`.
- Nocions d'XSLT 2.0/3.0: funcions, agrupacions, formateig avançat (només cultura general).
- Eines: processadors (Saxon, xsltproc), integració amb scripts.

## Exemple breu (XML → HTML)
```xslt
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/cataleg">
    <html><body><ul>
      <xsl:for-each select="producte">
        <li><xsl:value-of select="nom"/> — <xsl:value-of select="format-number(preu, '0.00')"/> €</li>
      </xsl:for-each>
    </ul></body></html>
  </xsl:template>
</xsl:stylesheet>
```

## Microexercicis
1. Ordena els productes per `preu` ascendent amb `<xsl:sort select="preu" data-type="number"/>`.
2. Mostra només productes amb `preu &gt; 20` mitjançant una condició.
3. Genera una taula HTML amb capçaleres `Nom` i `Preu`.

## CA vinculats (resum)
- Identifica tecnologies de conversió (XSLT) i descriu la seva sintaxi.
- Crea especificacions de transformació i obté sortides vàlides.
- Integra les transformacions en un flux de publicació bàsic.

## Enllaços útils
- XSLT 1.0 (W3C) i tutorial introductori.
- Processadors (Saxon, xsltproc) — guies d'ús.
