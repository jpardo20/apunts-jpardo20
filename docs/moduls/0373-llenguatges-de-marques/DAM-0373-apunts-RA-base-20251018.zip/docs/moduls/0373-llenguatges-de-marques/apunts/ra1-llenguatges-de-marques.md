# RA1 · Llenguatges de marques: concepte, estructura i namespaces

> **Versió base** · 2025-10-18 · Preparat per MkDocs · Estructura: RA/CA → Continguts → Exemples → Microexercicis → CA vinculats → Enllaços


## Objectius del RA
Comprendre els principis dels llenguatges de marques, distingint finalitats i característiques (text pla, metadades, interoperabilitat), i aplicar les regles de **ben format** i **namespaces** en documents XML.

## Continguts clau
- Què és un llenguatge de marques: text + metadades; etiquetes i atributs.
- Diferències d'ús: **XML** (intercanvi/estructura) vs **HTML** (presentació web).
- Ben format XML: pròleg, elements/atributs, entitats i escapament, jerarquia i tancament correcte.
- Encoding (`UTF-8`), caràcters especials i entitats (`&lt;`, `&amp;`, `&quot;`…).
- **Namespaces**: URIs, declaració per defecte i prefixos; resolució de conflictes de noms.

## Exemple breu: bé vs. malament
```xml
<!-- Bé (ben format, amb namespace) -->
<?xml version="1.0" encoding="UTF-8"?>
<cataleg xmlns="http://exemple.org/cataleg">
  <producte id="p1"><nom>Ratolí</nom><preu>14.95</preu></producte>
</cataleg>
```
```xml
<!-- Malament (etiqueta sense tancar i caràcter & sense escapar) -->
<cataleg>
  <producte id="p1"><nom>Ratolí & USB</producte>
</cataleg>
```

## Microexercicis
1. Indica quines regles de ben format es trenquen a l'exemple “malament” i proposa la correcció.
2. Afegeix un **namespace** per als elements `<preu>` amb prefix `pre` i torna a escriure l'exemple correcte.
3. Explica amb una frase per a què serveix l'atribut `xml:lang` i en quin cas el faries servir.

## CA vinculats (resum)
- Identifica característiques i avantatges dels llenguatges de marques.
- Distingeix àmbits d'aplicació d'XML i HTML.
- Justifica i aplica el **ben format** i els **namespaces** en documents XML.

## Enllaços útils
- XML 1.0 (W3C) — objectius i regles de ben format.
- MDN: introducció a XML i entitats.
