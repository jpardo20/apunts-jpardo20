# RA3 · Guions de client: DOM i esdeveniments (JavaScript)

> **Versió base** · 2025-10-18 · Preparat per MkDocs · Estructura: RA/CA → Continguts → Exemples → Microexercicis → CA vinculats → Enllaços


## Objectius del RA
Manipular el **DOM** des de JavaScript de client: seleccionar elements, escoltar esdeveniments i crear/modificar/eliminar nodes i estils de manera accessible i segura.

## Continguts clau
- Sintaxi mínima de JS al navegador; on col·locar els scripts; `defer`.
- DOM API: `querySelector`, `classList`, atributs, propietats i estils.
- Esdeveniments: `addEventListener`, delegació d'esdeveniments.
- Creació i eliminació de nodes: `createElement`, `append`, `remove`.
- Bones pràctiques: no bloquejar el render, evitar `innerHTML` indiscriminat, accessibilitat (`aria-*`).

## Exemple breu (DOM + events)
```html
<button id="tog">Mostra/Amaga</button>
<div id="panel" hidden>Detall del producte…</div>
<script defer>
  const b = document.querySelector('#tog');
  const p = document.querySelector('#panel');
  b.addEventListener('click', () => { p.hidden = !p.hidden; });
</script>
```

## Microexercicis
1. A partir d'un `<input>` i una `<ul>`, afegeix `<li>` amb el text introduït i esborra'l en fer clic.
2. Afegeix o treu la classe `destacat` a un element en passar el ratolí i retorna a l'estat inicial en sortir.
3. Explica quan utilitzaries delegació d'esdeveniments i dona un exemple de selector.

## CA vinculats (resum)
- Identifica llenguatges de guions de client i estàndards associats.
- Accedeix, crea, modifica i elimina elements del DOM.
- Canvia estils des de JS amb criteri d'accessibilitat.

## Enllaços útils
- MDN: Guia DOM i events.
- MDN: `querySelector`, `classList`, `addEventListener`.
