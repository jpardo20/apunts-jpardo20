# Apunts d'en Joan Pardo per DigiTechFP

En aquesta web publicaré els apunts dels meus mòduls per DigiTechFP

Ves a **[Presentacions](presentacions/index.html)** del menú per veure les que ja he publicat.

