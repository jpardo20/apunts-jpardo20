
# Tema 2: Conceptes bàsics: de Bases de Dades
<br>
<br>
UD01 - Introducció a les Bases de Dades

![data-base.png](./assets/img/data-base.png)

---

## Definició

**món real**: constituït pels objectes (materials o no) de la realitat que ens interessen i amb els quals haurem de treballar.

**món conceptual**: conjunt de coneixements o informacions obtinguts gràcies a l'observació de la part del món real que ens interessa. Un mateix món real pot donar lloc a diferents mons conceptuals, en funció de la manera de percebre la realitat, o els interessos de l'observador d'aquesta.

**món de les interpretacions**: representacions informàtiques, o dades, del món conceptual, necessàries per poder treballar.

--

![alt text](./assets/img/representacio-dades.png)

---

## Les dades i la seva representació

* **dades**: són representacions informàtiques de la informació disponible, relativa als objectes del món real del nostre interès.

* **món de les representacions**: està format per les dades informatitzades amb les quals treballem.


---

## Conversió de les concepcions en dades

* **fase de disseny lògic**: Es treballa amb el model abstracte de dades obtingut al final de l'etapa de disseny conceptual, per tal de traduir-ho al model de dades utilitzat pel SGBD amb el qual es vol implementar i mantenir la futura BD.

* **fase de disseny físic**: Es poden fer certes modificacions sobre l'esquema lògic obtingut en la fase de disseny anterior, per tal d'incrementar l'eficiència en algunes de les operacions que s'hagin de fer amb les dades.

---

## Entitats, atributs i valors

Tres elements caracteritzen fonamentalment les informacions:

**entitats**: són els objectes del món real que conceptualitzem. Són identificables, és a dir, distingibles els uns dels altres. I ens interessen algunes (com a mínim una) de les seves propietats

**atributs**: són les propietats de les entitats que ens interessen

**valors**: són els continguts concrets dels atributs, les determinacions concretes que assoleixen.

---

## Exemple d'entitat, atributs i valors (1/4)

Considerarem que una pel·lícula concreta és una entitat, perquè és un objecte del món real, que hem conceptualitzat dins d'una categoria (la dels films cinematogràfics), i que al mateix temps és distingible d'altres entitats de la mateixa categoria (és a dir, d'altres films).

D'aquesta pel·lícula concreta ens interessaran alguns aspectes, que anomenarem atributs, com per exemple, el títol, el director i l'any de producció.

Finalment, aquests atributs adoptaran uns valors concrets com ara, i respectivament, Paths of glory, Stanley Kubrick i 1957.

--

## Exemple d'entitat, atributs i valors (2/4)

![alt text](./assets/img/exemple-entitat-atribut-valor.png)

font [imdb.com](https://www.imdb.com/)

--

## Exemple d'entitat, atributs i valors (3/4)

Si només coneixem dos d'aquests tres elements, no disposarem d'una veritable informació, ja que es produirà alguna de les mancances següents:

desconeixerem l'entitat (l'objecte) a què va associat l'atribut i el valor respectiu, i per tant no servirà de gaire conèixer els altres aspectes.
desconeixerem quin atribut (propietat) de l'entitat adopta el valor obtingut, la qual cosa pot donar lloc a equívocs.

Sabrem que l'entitat té una certa propietat, però en desconeixerem el valor, i per tant aquest coneixement difícilment ens resultarà útil.

--

## Exemple d'entitat, atributs i valors (4/4)

![alt text](./assets/img/exemple-entitat-atribut-valor-amb-buits.png)

font [imdb.com](https://www.imdb.com/)

---

## Entitats tipus i entitats instància

**entitat tipus**: es tracta d'un tipus genèric d'entitat o, si es prefereix, d'una abstracció, que fa referència a una classe de coses com, per exemple, els cotxes, en general.

**entitat instància**: es refereix a la conceptualització d'un objecte concret del món real, com ara un cotxe concret, distingible dels altres objectes del mateix tipus, gràcies a alguna propietat (com podria ser el valor de l'atribut Matrícula).

--

![alt text](./assets/img/entitat-tipus.png)

---

## Tipus de dada

**tipus de dada**: defineix un conjunt de valors amb unes característiques comunes que els fan compatibles, per la qual cosa també defineix una sèrie d'operacions admissibles sobre aquests valors.

--

## Exemple de tipus de dada

Podem considerar els nombres enters com un tipus de dada (diferent d'altres tipus, com per exemple els nombres reals, els caràcters, etc.), sobre el qual es poden definir certes operacions, com la suma, la resta, la multiplicació o la divisió entera (però no la divisió exacta, que només és possible entre els nombres reals).

---

## Exemple de domini (1/2)

Imaginem que, en l'àmbit d'uns estudis determinats, s'exigeix un mínim d'assistència a classes presencials per tal d'aconseguir el títol corresponent, independentment de les qualificacions obtingudes.
Imaginem que s'admet, durant tot el curs acadèmic, un màxim de vint faltes injustificades. Doncs bé, hi podria haver un atribut de l'entitat ALUMNES, anomenat, per exemple, nombreFaltes, que recollís aquesta circumstància.
Aquest atribut podria emmagatzemar dades de tipus enter. I també se'n podria limitar el domini de 0 (per indicar que no hi ha hagut cap inassistència) a 20 faltes injustificades, ja que en arribar a aquest límit es produiria l'expulsió de l'alumne.

--

## Exemple de domini (2/2)

![alt text](./assets/img/exemple-domini.png)

---

## Valor `nul` dels atributs

De vegades, el valor d'un atribut és desconegut o, fins i tot, no existeix. Per representar aquesta circumstància, l'atribut en qüestió haurà d'admetre el valor nul.

L'expressió valor nul indica que no hi ha cap valor associat a un atribut determinat d'una entitat instància concreta.





---

## Exemple de valor `nul` (1/2)

Considerem ara que l'entitat ALUMNES disposa d'un atribut anomenat telefon.

Si l'atribut telefon, no, admet valors nuls, el sistema no permetrà que es matriculin persones que no disposessin de telèfon.

Però, si en definir el domini, s'indica que sí que admet valors nuls, el sistema acceptarà la matrícula de les persones que no disposin de telèfon.

No confondre valor nul amb el zero, o amb l'espai en blanc.


---

## Exemple de valor `nul` (2/2)

![alt text](./assets/img/exemple-valor-null.png)

---

## Atribut identificador (clau primària `PK`)

**atribut identificador**: és l'atribut o atributs que permet distingir inequívocament cada entitat instància de la resta, pel fet que el seu valor és únic, i no es repeteix en diferents entitats instància.

Els atributs d'una entitat seran identificadors, o no, en funció de l'objecte del món real que l'entitat vulgui modelitzar.




---

## Exemple d'atribut identificador (clau primaria `PK`) (1/2)

L'atribut dni pot servir molt bé per identificar les instàncies d'una entitat que modelitzi els alumnes d'un centre docent, ja que cada alumne tindrà un dni diferent.


---

## Exemple d'atribut identificador (clau primaria `PK`) (2/2)

![alt text](./assets/img/exemple-atribut-identificador.png)

---

## Atributs identificadors (clau primària PK)

Tot atribut o conjunt d'atributs que permeten identificar inequívoca.

Per tant, hi haurà casos en què caldrà més d'un atribut per poder identificar una instància específica d'una entitat.

Per definició, ni els atributs identificadors ni els que formen part d'una clau poden admetre mai el valor nul, perquè aleshores no servirien per distingir les entitats instància sense valor en un dels tipus d'atribut esmentat de la resta.




---

## Exemple d'Atributs identificadors (clau primària `PK`) (1/2)

Per tal de diferenciar les instàncies d'una entitat que vol reflectir les notes finals dels alumnes en cada assignatura en què s'hagin matriculat, cal combinar els valors de dos atributs: un que designi l'alumne de què es tracti (típicament, el DNI), i un altre que indiqui l'assignatura a la qual correspon la nota (que podria ser una cosa com ara CodiAssignatura).





---

## Exemple d'Atributs identificadors (clau primària `PK`) (2/2)


![alt text](./assets/img/exemple-atribut-identificadors-2.png)

---

## El món de les representacions

**dades** => informacions representades informàticament

món de les dades el món de les representacions.

La representació més freqüent en l'àmbit informàtic de les BD és l'anomenada representació tabular (o en forma de taula).

BDs són conjunts de fitxers interrelacionats





---

## Representacions tabulars i la seva implementació (1/2)

Les informacions són conceptualitzacions obtingudes a partir de l'observació del món real.


**entitat**:    **`COTXES`**

**atributs**:   **`Matrícula`** i
                **`Marca`**


![alt text](./assets/img/representacions-tabulars.png)


---

## Representacions tabulars i la seva implementació (1/2)

./assets/img/representacions-tabulars

![alt text](./assets/img/representacions-tabulars-2.png)