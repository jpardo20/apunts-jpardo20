# Llicència del repositori (dual)

Aquest repositori separa la llicència de **codi** i de **contingut**:

- **Codi** (scripts, workflows, fitxers de configuració): llicenciat sota **MIT** — veu `LICENSE-CODE`.
- **Contingut** (pàgines Markdown, textos, imatges integrades en els apunts): llicenciat sota **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)** — veu `LICENSE-CONTENT`.

Si combines codi i contingut en un mateix fitxer, preval la llicència de **contingut** per a la part textual i de **codi** per a la part de script.
